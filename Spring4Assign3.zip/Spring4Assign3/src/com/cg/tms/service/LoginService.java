package com.cg.tms.service;

import java.util.ArrayList;

import com.cg.tms.dto.*;

public interface LoginService {

	public Login getUserById(String unm);
	public Trainee getTraineeById(int id);
	public Trainee addUserDetails(Trainee userDetails);
	public Login addUser(Login user);
	public ArrayList<Trainee> getAllUserDetails();
	public boolean deleteUser(int id);
	public int updateUser(String unm);
	
	public boolean validateUser(Login user);
}
