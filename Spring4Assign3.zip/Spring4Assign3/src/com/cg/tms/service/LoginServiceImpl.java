package com.cg.tms.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.tms.dao.LoginDao;
import com.cg.tms.dto.Login;
import com.cg.tms.dto.Trainee;

@Service
public class LoginServiceImpl implements LoginService {

	
	@Autowired
	LoginDao logDao;
	
	@Override
	public Login getUserById(String unm) {
		
		
		return logDao.getUserById(unm);
	}

	@Override
	public Trainee addUserDetails(Trainee userDetails) {
		
		return logDao.addUserDetails(userDetails);
	}

	@Override
	public Login addUser(Login user) {
		
		return logDao.addUser(user);
	}

	@Override
	public ArrayList<Trainee> getAllUserDetails() {
		
		return logDao.getAllUserDetails();
	}

	@Override
	public boolean deleteUser(int id) {
		
		return logDao.deleteUser(id);
	}

	@Override
	public Trainee updateUser(Trainee trainee) {
		
		return logDao.updateUser(trainee);
	}

	@Override
	public boolean validateUser(Login user) {
		
		Login daouser=logDao.getUserById(user.getUserName());
		if(user.getUserName().equalsIgnoreCase(daouser.getUserName()) && user.getUserPass().equalsIgnoreCase(daouser.getUserPass())) 
		{
		   return true;	
		}
		else
		{
		return false;
		}
	}

	@Override
	public Trainee getTraineeById(int id) {
		
		return logDao.getTraineeById(id);
	}

	
}
