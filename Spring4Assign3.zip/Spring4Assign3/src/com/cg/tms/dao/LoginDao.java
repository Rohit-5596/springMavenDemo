package com.cg.tms.dao;

import java.util.ArrayList;

import com.cg.tms.dto.Login;
import com.cg.tms.dto.Trainee;

public interface LoginDao {

	public Login getUserById(String unm);
	public Trainee getTraineeById(int id);
	public Trainee addUserDetails(Trainee userDetails);
	public Login addUser(Login user);
	public ArrayList<Trainee> getAllUserDetails();
	public boolean deleteUser(int id);
	public Trainee updateUser(Trainee trainee);
}
