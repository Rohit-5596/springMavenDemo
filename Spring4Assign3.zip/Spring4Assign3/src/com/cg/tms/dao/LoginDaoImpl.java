package com.cg.tms.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Component;


import com.cg.tms.dto.Login;
import com.cg.tms.dto.Trainee;

@Component
@Transactional
public class LoginDaoImpl implements LoginDao {

	
	@PersistenceContext
	EntityManager em;
	
	@Override
	public Login getUserById(String unm) {

	    System.out.println("in LoginDao setUserById");
	    Login user=em.find(Login.class, unm);
		return user;
	}

	@Override
	public Trainee addUserDetails(Trainee userDetails) {
		
		em.persist(userDetails);
		Trainee reg=em.find(Trainee.class, userDetails.getTraineeId());
		return reg;
	}

	@Override
	public Login addUser(Login user) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<Trainee> getAllUserDetails() {
		
		String selectUserQry="SELECT reg FROM Trainee reg";
		TypedQuery<Trainee> tq=em.createQuery(selectUserQry,Trainee.class); 
		ArrayList<Trainee> userList=(ArrayList) tq.getResultList();
		
		return userList;
	}

	@Override
	public boolean deleteUser(int id) { 
		  
	   Trainee tDto=em.find(Trainee.class,id);  
	    em.remove(tDto);  
	    /*Login log=em.find(Login.class,unm);  
	    em.remove(log);*/ 
	
	return true;
	}

	@Override
	public Trainee updateUser(Trainee trainee) {
		
//		Trainee t=em.find(Trainee.class, trainee);
//		String str="Update Trainee trainee SET trainee.traineeName= :newname,"
//				+ "trainee.traineeLocation= :newloc,trainee.traineeDomain= :newdomain "
//				+ "WHERE trainee.traineeId= :id";
//		
//		Query query=em.createQuery(str);
//		query.setParameter("newname",t.getTraineeName() );
//		query.setParameter("newloc", t.getTraineeLocation());
//		query.setParameter("newdomain", t.getTraineeDomain());
//		query.setParameter("id", t.getTraineeId());
//	    int update=query.executeUpdate();
//		
//		
//		return update;
		Trainee t=em.find(Trainee.class, trainee.getTraineeId());
		t.setTraineeDomain(trainee.getTraineeDomain());
		t.setTraineeLocation(trainee.getTraineeLocation());
		t.setTraineeName(trainee.getTraineeName());
		return t;
		
	}

	@Override
	public Trainee getTraineeById(int id) {
		
		 System.out.println("in LoginDao getTraineeById");
		    Trainee user=em.find(Trainee.class, id);
			return user;
	
	}

}
