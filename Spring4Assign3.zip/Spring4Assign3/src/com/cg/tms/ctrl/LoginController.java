package com.cg.tms.ctrl;

import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.tms.util.*;
import com.cg.tms.dto.Login;
import com.cg.tms.dto.Trainee;
import com.cg.tms.service.*;

@Controller
public class LoginController {

	@Autowired
	LoginService logSer;//for validateUser
	
	@RequestMapping(value="/ShowLoginPage")
	public String dispLoginPage(Model model)
	{
		Login lgg=new Login();
		lgg.setUserName("Enter user Id here");
		model.addAttribute("log",lgg);
		return "Login";//Login is view name...now create Login.jsp
		
	}
	
	@RequestMapping(value="/ValidateUser")
	public String validateUser(@ModelAttribute("log") @Valid Login lgg,BindingResult result,Model model) {
		
		if(result.hasFieldErrors())
		{
			return "Login";
		}
		else
		{
		 System.out.println("user entered: "+lgg);
		 if(logSer.validateUser(lgg))
		 {
			return "Success";
		 }
		 else
		 {
			model.addAttribute("MsgObj", "Please check your Password");
		     return "Login";
		 }
		}
	}
	
/**************ShowRegisterPage*****************/
	
	@RequestMapping(value="/ShowRegisterPage")
	public String dispRegisterPage(Model model) {
		
		Trainee reg=new Trainee();
		ArrayList<String> domainList=new ArrayList<String>();
		domainList.add("BI");
		domainList.add("JAVA Cloud");
		domainList.add("Data Science");
		domainList.add("Dot Net");
		model.addAttribute("domainListObj", domainList);
		
		model.addAttribute("regObj", reg);
		return "Register";
		
	}
	
/**************AddUserDetails.obj*****************/
	
	@RequestMapping(value="/AddUserDetails")
	public String insertUserDetails(@ModelAttribute("regObj") Trainee reg, BindingResult result,Model model )
	{
		
		/*String str=MyStringDateUtil.fromArrayToCommaSeparatedString(reg.getSkillSet());
		reg.setSkillSetStr(str);*/
		logSer.addUserDetails(reg);
		ArrayList<Trainee> userList=logSer.getAllUserDetails();
		model.addAttribute("UserListObj",userList);
		return "ListAllUser";
		
	}
	
	/***********ShowDeleteUserPage**********/
	
	@RequestMapping(value="/ShowDeleteUserPage")
	public String dispDeletePage(Model model) {
		
		Trainee delete=new Trainee();
		
		model.addAttribute("deleteObj", delete);
		return "DeleteUser";
		
	}
	
/**************DeleteUserInfo****************/
	
	@RequestMapping(value="/DeleteUserDetails")
	public String deleteUserDetails(@ModelAttribute("deleteObj") Trainee tr,Model model)
	{
		Trainee t=logSer.getTraineeById(tr.getTraineeId());
		model.addAttribute("deleteUserObj",t);
		//logSer.deleteUser(tr.getTraineeId());
		/*ArrayList<Trainee> userList=logSer.getAllUserDetails();
		model.addAttribute("UserListObj",userList);*/
		System.out.println("data deleted for...."+tr.toString());
		return "DeleteUser";
	}
	
	
	/**************DeleteUserSuccess****************/
	
	@RequestMapping(value="/DeleteUserSuccess")
	public String deleteUserSuccess(@RequestParam("uid") int uid,Model model)
	{
		
		logSer.deleteUser(uid);
		/*ArrayList<Trainee> userList=logSer.getAllUserDetails();
		model.addAttribute("UserListObj",userList);*/
		System.out.println("data deleted for....");
		return "DeleteUserSuccess";
	}
	
	/********************ShowRetrieveAllPage*******************/
	
	@RequestMapping(value="/ShowRetrieveAllPage")
	public String dispRetrieveAllPage(Model model) {
		
		//Trainee showAll=new Trainee();
		/*ArrayList<String> domainList=new ArrayList<String>();
		domainList.add("BI");
		domainList.add("JAVA Cloud");
		domainList.add("Data Science");
		domainList.add("Dot Net");*/
		
		//model.addAttribute("domainListObj", domainList);
		ArrayList<Trainee> userList=logSer.getAllUserDetails();
		model.addAttribute("UserListObj", userList);
		return "ListAllUser";
		
	}
	
	/*******************ShowRetrieveATraineePage*******************/
	
	@RequestMapping(value="/ShowRetrieveATraineePage")
	public String dispRetrieveATraineePage(Model model) {
		
		Trainee search=new Trainee();
		model.addAttribute("showATraineeObj",search);
		return "ShowATrainee";
		
	}
	
	/*******************ShowATrainee*******************/
	
	@RequestMapping(value="/ShowATraineeDetails")
	public String showAUserDetails(@ModelAttribute("showATraineeObj") Trainee tr,Model model)
	{
		Trainee trainee=logSer.getTraineeById(tr.getTraineeId());
		model.addAttribute("showTraineeObj",trainee);
		//logSer.deleteUser(tr.getTraineeId());
		/*ArrayList<Trainee> userList=logSer.getAllUserDetails();
		model.addAttribute("UserListObj",userList);*/
		System.out.println("data for...."+tr.getTraineeId()+" "+tr.toString());
		return "ShowATrainee";
	}
	
	/*******************ShowModifyATrainee*******************/
	
	@RequestMapping(value="/ShowModifyATraineePage")
       public String dispUpdatePage(Model model) {
		
		Trainee update=new Trainee();
		
		model.addAttribute("updateObj", update);
		return "UpdateUser";
		
	}
	
	/**************UpdateUserDetails***********************/
	
	@RequestMapping(value="/UpdateUserDetails")
    public String updateUser(@ModelAttribute("updateObj") Trainee tr,Model model) {
		
		Trainee t=logSer.getTraineeById(tr.getTraineeId());
		model.addAttribute("updateObj",t);

		
		return "UpdateUser";	
	}
	
	/*****************UpdateUserSuccess*******************/
	
	@RequestMapping(value="/UpdateUserSuccess")
	public String updateUserSuccess(@ModelAttribute("updateObj") Trainee tr,Model model)
	{
		
	    Trainee updated=logSer.updateUser(tr);
	    System.out.println("data modified for...."+tr);
	    model.addAttribute("updatedUserObj",updated);
		return "UpdateUserSuccess";
	}
	
}
